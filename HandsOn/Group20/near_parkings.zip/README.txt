- como se inicia?
1º creamos e iniciamos el entorno e instalamos las dependencias desde la carpeta raíz, la anterior a app digamos
2º lanzamos la bbdd en segundo plano con "Docker compose up -d"
3º realizamos la 1ª migracion de las tablas a la BBDD para que funcione con "alembic upgrade head"
4º lanzamos el servidor con nuestra app(el backend) con "uvicorn app.main:app --reload
5º lanzamos el frontend desde la carpeta "client" con "python frontend.py"


# CREACION ENTORNO DE TRABAJO PARA INSTALAR LAS DEPENDENCIAS:

python -m venv .venv				#crea un entorno PERSONAL, si lo cambias de directorio ya no sirve y hay que crear otro en ese nuevo directorio

.venv\Scripts\activate 				#activa entorno, para LINUX el mandato es  .venv/bin/Activate.ps1 	

pip freeze > requirements.txt 		#NO LO EJECUTEIS, crea requirements guardando dependencias, USADO PARA CREAR EL REQUIREMENTS QUE TENEIS QUE USAR

pip install -r requirements.txt 	#instala las dependencias del requirements (el requierements.txt del ZIP tiene las dependencias necesarias)
_________________________________________________________________________________________
# ACTIVACION/MODIFICACIONES BBDD:

docker compose up -d                #levanta la base de datos, NECESARIO TENER DOCKER DESKTOP INSTALADO

docker compose down                 #la desactiva

alembic revision --autogenerate -m "MODIFICACION_HECHA"       #genera un .py en versiones si hay cambios en los modelos de la bbdd

alembic upgrade head                #BBDD ACTIVA PARA ESTO! ejecuta el .py anterior generando los cambios en la bbdd, HAY QUE HACERLO LA PRIMERA VEZ QUE EJECUTES LA BBDD

			#estos dos de alembic tendreis que hacerlos con la bbdd levantada la primera vez para migrar las tablas
_________________________________________________________________________________________
# ACTIVACION SERVIDOR LOCALHOST PARA LANZAR BACKEND(DESDE LA CARPETA RAIZ near_parkings):

uvicorn main:app --reload 			#levanta api
_________________________________________________________________________________________
# PARA LANZAR FRONTEND: DESDE LA CARPETA CLIENT

frontend.py
